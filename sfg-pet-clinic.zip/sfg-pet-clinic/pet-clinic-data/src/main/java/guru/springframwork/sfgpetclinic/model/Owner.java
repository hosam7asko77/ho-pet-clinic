package guru.springframwork.sfgpetclinic.model;

public class Owner extends Person {
}
