package guru.springframwork.sfgpetclinic.model;

public class PetType {
}
